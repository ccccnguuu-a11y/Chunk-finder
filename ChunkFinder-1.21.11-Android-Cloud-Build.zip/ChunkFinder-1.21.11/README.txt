ChunkFinder 1.0.0 - Minecraft 1.21.11 Fabric (client-side)

FEATURES
- Press I to open the ChunkFinder + ESP screen.
- Scan target blocks in client-loaded chunks only.
- ESP modes: LINE, BOX, BOTH.
- ESP range control; default 24 blocks.
- Scan and ESP have hard caps to limit work on lower-end devices.
- No server-side component.

TARGETS
Chests, trapped chests, barrels, ender chests, all 17 shulker box colors,
furnaces, blast furnaces, smokers, crafting tables, enchanting tables, anvils,
brewing stands, hoppers, and spawners.

LIMITATIONS
- The mod only inspects chunks already loaded by the client. It does not
  request or force-load chunks and cannot read unloaded chunk data.
- A scan stops after 120,000 block checks or 80 results.
- ESP stops after 120,000 block checks or 100 visible targets per refresh.
- The GUI and rendering have not been tested in a running Minecraft instance.

BUILD REQUIREMENTS
- Java 21
- Gradle 9.2 or newer
- Internet on the build computer for the first Gradle dependency resolution.
- Minecraft 1.21.11, Yarn 1.21.11+build.4, Fabric Loader 0.18.4,
  Fabric API 0.141.3+1.21.11.

BUILD
- Windows: run build-windows.bat from this folder.
- Or run: gradle build
- Output (if build succeeds): build/libs/chunkfinder-1.0.0.jar

IMPORTANT
This archive is source code, not a compiled mod JAR. A real JAR requires a
successful Gradle build against the Minecraft and Fabric dependencies.
