@echo off
setlocal
cd /d "%~dp0"
echo Building ChunkFinder for Minecraft 1.21.11 Fabric...
echo.
java -version
if errorlevel 1 (
  echo ERROR: Java was not found. Install Java 21 first.
  pause
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle was not found on PATH.
  echo This project requires Gradle 9.2 or newer and an Internet connection
  echo on the build computer for the first dependency download.
  pause
  exit /b 1
)
gradle --version
gradle build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the complete error output for diagnosis.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCESS. JAR files are in build\libs
pause
