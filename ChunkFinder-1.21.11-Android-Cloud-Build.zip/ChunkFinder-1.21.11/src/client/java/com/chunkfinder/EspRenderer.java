package com.chunkfinder;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public final class EspRenderer {
    private EspRenderer() {}

    private static final List<BlockPos> VISIBLE_TARGETS = new ArrayList<>();
    private static long lastRefreshTick = Long.MIN_VALUE;
    private static BlockPos lastPlayerPos = null;
    private static int lastRange = -1;
    private static ClientWorld lastWorld = null;
    private static final int MAX_RENDERED_TARGETS = 100;
    private static final int MAX_BLOCK_CHECKS_PER_REFRESH = 120_000;

    /** Called from the client tick, not from the render callback. */
    public static void tick(MinecraftClient mc) {
        if (!EspConfig.enabled || mc.player == null || mc.world == null) {
            VISIBLE_TARGETS.clear();
            lastPlayerPos = null;
            lastWorld = null;
            return;
        }

        BlockPos playerPos = mc.player.getBlockPos();
        long tick = mc.world.getTime();
        boolean worldChanged = lastWorld != mc.world;
        boolean movedChunk = lastPlayerPos == null
                || (lastPlayerPos.getX() >> 4) != (playerPos.getX() >> 4)
                || (lastPlayerPos.getZ() >> 4) != (playerPos.getZ() >> 4);
        if (!worldChanged && !movedChunk && lastRange == EspConfig.range && tick - lastRefreshTick < 20) return;

        VISIBLE_TARGETS.clear();
        lastPlayerPos = playerPos.toImmutable();
        lastWorld = mc.world;
        lastRange = EspConfig.range;
        lastRefreshTick = tick;

        int radius = Math.max(8, Math.min(64, EspConfig.range));
        int minChunkX = (playerPos.getX() - radius) >> 4;
        int maxChunkX = (playerPos.getX() + radius) >> 4;
        int minChunkZ = (playerPos.getZ() - radius) >> 4;
        int maxChunkZ = (playerPos.getZ() + radius) >> 4;
        int minY = Math.max(mc.world.getBottomY(), playerPos.getY() - radius);
        int maxY = Math.min(mc.world.getTopY() - 1, playerPos.getY() + radius);
        long radiusSq = (long) radius * radius;
        int checkedBlocks = 0;

        scanLoop:
        for (int cx = minChunkX; cx <= maxChunkX; cx++) {
            for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                int x0 = chunk.getPos().getStartX();
                int z0 = chunk.getPos().getStartZ();
                for (int x = 0; x < 16; x++) {
                    int wx = x0 + x;
                    int dx = wx - playerPos.getX();
                    if ((long) dx * dx > radiusSq) continue;
                    for (int z = 0; z < 16; z++) {
                        int wz = z0 + z;
                        int dz = wz - playerPos.getZ();
                        if ((long) dx * dx + (long) dz * dz > radiusSq) continue;
                        for (int y = minY; y <= maxY; y++) {
                            if (++checkedBlocks > MAX_BLOCK_CHECKS_PER_REFRESH) break scanLoop;
                            int dy = y - playerPos.getY();
                            if ((long) dx * dx + (long) dy * dy + (long) dz * dz > radiusSq) continue;
                            BlockPos pos = new BlockPos(wx, y, wz);
                            Block block = chunk.getBlockState(pos).getBlock();
                            if (!BlockScanner.TARGETS.contains(block)) continue;
                            VISIBLE_TARGETS.add(pos.toImmutable());
                            if (VISIBLE_TARGETS.size() >= MAX_RENDERED_TARGETS) break scanLoop;
                        }
                    }
                }
            }
        }
    }

    public static void render(WorldRenderContext ctx) {
        if (!EspConfig.enabled || VISIBLE_TARGETS.isEmpty()
                || ctx.matrices() == null || ctx.consumers() == null) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        // Fabric 1.21.11 expects world-render vertices to be camera-relative.
        // Guard the render state because some renderers may invoke the event
        // while the camera state is not initialized yet.
        if (ctx.worldState() == null || ctx.worldState().cameraRenderState == null
                || !ctx.worldState().cameraRenderState.initialized
                || ctx.worldState().cameraRenderState.pos == null) return;
        Vec3d camera = ctx.worldState().cameraRenderState.pos;
        MatrixStack matrices = ctx.matrices();
        VertexConsumer lines = ctx.consumers().getBuffer(RenderLayers.lines());
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        Vec3d eye = mc.player.getEyePos();
        double eyeX = eye.x - camera.x;
        double eyeY = eye.y - camera.y;
        double eyeZ = eye.z - camera.z;

        for (BlockPos pos : VISIBLE_TARGETS) {
            Block block = mc.world.getBlockState(pos).getBlock();
            float r = 1f, g = 0.3f, b = 0.3f;
            if (block == Blocks.CHEST || block == Blocks.BARREL || block == Blocks.TRAPPED_CHEST) {
                r = 0.2f; g = 0.75f; b = 1f;
            } else if (block == Blocks.SPAWNER) {
                r = 1f; g = 0.1f; b = 1f;
            } else if (block == Blocks.ENCHANTING_TABLE) {
                r = 0.7f; g = 0.3f; b = 1f;
            }

            double x = pos.getX() - camera.x;
            double y = pos.getY() - camera.y;
            double z = pos.getZ() - camera.z;
            if (EspConfig.mode == EspConfig.Mode.BOX || EspConfig.mode == EspConfig.Mode.BOTH) {
                drawBox(lines, matrix, new Box(x, y, z, x + 1, y + 1, z + 1).expand(0.002), r, g, b);
            }
            if (EspConfig.mode == EspConfig.Mode.LINE || EspConfig.mode == EspConfig.Mode.BOTH) {
                edge(lines, matrix, eyeX, eyeY, eyeZ,
                        x + 0.5, y + 0.5, z + 0.5, r, g, b);
            }
        }
    }

    private static void drawBox(VertexConsumer v, Matrix4f m, Box b, float r, float g, float bl) {
        double x1=b.minX, y1=b.minY, z1=b.minZ, x2=b.maxX, y2=b.maxY, z2=b.maxZ;
        edge(v,m,x1,y1,z1,x2,y1,z1,r,g,bl); edge(v,m,x2,y1,z1,x2,y1,z2,r,g,bl);
        edge(v,m,x2,y1,z2,x1,y1,z2,r,g,bl); edge(v,m,x1,y1,z2,x1,y1,z1,r,g,bl);
        edge(v,m,x1,y2,z1,x2,y2,z1,r,g,bl); edge(v,m,x2,y2,z1,x2,y2,z2,r,g,bl);
        edge(v,m,x2,y2,z2,x1,y2,z2,r,g,bl); edge(v,m,x1,y2,z2,x1,y2,z1,r,g,bl);
        edge(v,m,x1,y1,z1,x1,y2,z1,r,g,bl); edge(v,m,x2,y1,z1,x2,y2,z1,r,g,bl);
        edge(v,m,x2,y1,z2,x2,y2,z2,r,g,bl); edge(v,m,x1,y1,z2,x1,y2,z2,r,g,bl);
    }

    private static void edge(VertexConsumer v, Matrix4f m, double x1, double y1, double z1,
                             double x2, double y2, double z2, float r, float g, float b) {
        v.vertex(m, (float)x1, (float)y1, (float)z1).color(r, g, b, 1f).normal(0, 1, 0);
        v.vertex(m, (float)x2, (float)y2, (float)z2).color(r, g, b, 1f).normal(0, 1, 0);
    }
}
