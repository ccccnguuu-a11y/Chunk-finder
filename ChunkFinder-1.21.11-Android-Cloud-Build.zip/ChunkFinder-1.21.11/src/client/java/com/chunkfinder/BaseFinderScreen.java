package com.chunkfinder;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class BaseFinderScreen extends Screen {
    private int radiusChunks = 2;
    private int resultOffset = 0;
    private List<String> results = List.of("Chưa quét. Nhấn SCAN để tìm block trong chunk đã tải.");

    public BaseFinderScreen() { super(Text.literal("ChunkFinder + ESP")); }

    @Override
    protected void init() {
        int cx = width / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("SCAN (" + radiusChunks + " chunk)"), b -> {
            if (client != null && client.player != null && client.world != null) {
                results = BlockScanner.scan(client, radiusChunks);
                resultOffset = 0;
            }
        }).dimensions(cx - 110, 42, 220, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Radius -"), b -> {
            radiusChunks = Math.max(1, radiusChunks - 1); clearAndInit();
        }).dimensions(cx - 170, 42, 50, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Radius +"), b -> {
            radiusChunks = Math.min(6, radiusChunks + 1); clearAndInit();
        }).dimensions(cx + 120, 42, 50, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("ESP: " + (EspConfig.enabled ? "ON" : "OFF")), b -> {
            EspConfig.enabled = !EspConfig.enabled; clearAndInit();
        }).dimensions(cx - 110, 72, 220, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Mode: " + EspConfig.mode), b -> {
            EspConfig.mode = switch (EspConfig.mode) {
                case LINE -> EspConfig.Mode.BOX;
                case BOX -> EspConfig.Mode.BOTH;
                case BOTH -> EspConfig.Mode.LINE;
            }; clearAndInit();
        }).dimensions(cx - 110, 97, 220, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("ESP range: " + EspConfig.range + " blocks"), b -> {
            EspConfig.range = EspConfig.range >= 64 ? 16 : EspConfig.range + 16;
            clearAndInit();
        }).dimensions(cx - 110, 122, 220, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Kết quả trước"), b -> {
            resultOffset = Math.max(0, resultOffset - 8);
        }).dimensions(cx - 110, height - 52, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Kết quả sau"), b -> {
            resultOffset = Math.min(Math.max(0, results.size() - 1), resultOffset + 8);
        }).dimensions(cx + 10, height - 52, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Đóng"), b -> close())
                .dimensions(cx - 50, height - 27, 100, 20).build());
    }

    private void clearAndInit() { clearChildren(); init(); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 15, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, "Kết quả quét:", 16, 155, 0x55FFFF);
        int y = 168;
        int end = Math.min(results.size(), resultOffset + Math.max(1, (height - 235) / 12));
        for (int i = resultOffset; i < end; i++) {
            context.drawTextWithShadow(textRenderer, results.get(i), 16, y, 0xDDDDDD);
            y += 12;
        }
        context.drawTextWithShadow(textRenderer, "I: mở menu | ESP chỉ xét block trong chunk đã tải", 16, height - 38, 0x888888);
    }

    @Override public boolean shouldPause() { return false; }
}
