package com.chunkfinder;

public final class EspConfig {
    private EspConfig() {}

    public static boolean enabled = true;
    // A modest default helps avoid excessive scanning on low-end phones.
    public static int range = 24;
    public static Mode mode = Mode.BOTH;

    public enum Mode { LINE, BOX, BOTH }
}
