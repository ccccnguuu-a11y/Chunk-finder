package com.chunkfinder;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class BlockScanner {
    private BlockScanner() {}

    public static final Set<Block> TARGETS = Set.of(
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.ENDER_CHEST,
            Blocks.SHULKER_BOX, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX,
            Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX,
            Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX,
            Blocks.LIGHT_GRAY_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX,
            Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX,
            Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX,
            Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.CRAFTING_TABLE,
            Blocks.ENCHANTING_TABLE, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
            Blocks.BREWING_STAND, Blocks.HOPPER, Blocks.SPAWNER
    );

    public static List<String> scan(MinecraftClient client, int radiusChunks) {
        List<String> found = new ArrayList<>();
        if (client.player == null || client.world == null) return List.of("Không có thế giới để quét.");

        BlockPos origin = client.player.getBlockPos();
        ChunkPos center = new ChunkPos(origin);
        radiusChunks = Math.max(1, Math.min(6, radiusChunks));
        int radius = radiusChunks * 16;
        int minY = Math.max(client.world.getBottomY(), origin.getY() - radius);
        int maxY = Math.min(client.world.getTopY() - 1, origin.getY() + radius);
        int checkedChunks = 0;
        int foundCount = 0;
        boolean capped = false;
        int checkedBlocks = 0;
        final int maxBlockChecks = 120_000;

        for (int cx = -radiusChunks; cx <= radiusChunks && !capped; cx++) {
            for (int cz = -radiusChunks; cz <= radiusChunks && !capped; cz++) {
                WorldChunk chunk = client.world.getChunkManager().getWorldChunk(center.x + cx, center.z + cz);
                if (chunk == null) continue; // Never request or force-load an unloaded chunk.
                checkedChunks++;
                int x0 = chunk.getPos().getStartX();
                int z0 = chunk.getPos().getStartZ();
                for (int x = 0; x < 16 && !capped; x++) {
                    for (int z = 0; z < 16 && !capped; z++) {
                        for (int y = minY; y <= maxY; y++) {
                            if (++checkedBlocks > maxBlockChecks) { capped = true; break; }
                            int wx = x0 + x;
                            int wz = z0 + z;
                            int dx = wx - origin.getX();
                            int dy = y - origin.getY();
                            int dz = wz - origin.getZ();
                            if ((long) dx * dx + (long) dy * dy + (long) dz * dz > (long) radius * radius) continue;
                            BlockPos pos = new BlockPos(wx, y, wz);
                            Block block = chunk.getBlockState(pos).getBlock();
                            if (!TARGETS.contains(block)) continue;
                            found.add(block.getName().getString() + " @ " + wx + ", " + y + ", " + wz);
                            foundCount++;
                            if (foundCount >= 80) { capped = true; break; }
                        }
                    }
                }
            }
        }

        if (foundCount == 0) found.add("Không tìm thấy block mục tiêu trong chunk đã tải.");
        if (capped) found.add("Đã chạm giới hạn quét an toàn (120.000 block hoặc 80 kết quả) để hạn chế lag.");
        found.add("Chunk đã kiểm tra: " + checkedChunks + " | Kết quả: " + foundCount);
        found.add("Lưu ý: chỉ quét chunk đã tải, không thể thấy dữ liệu chunk chưa tải.");
        return found;
    }
}
